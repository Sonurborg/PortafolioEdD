package dci.ed;

public class Pila {
    // agregar los elementos que permiten implementar una Pila

    /*
     *  Método que permite agregar un elemento desde el frente de la pila
     */
    public void push(int valor){
        // implementar
    }

    /*
     *  Método que permite eliminar un elemento desde el frente de la pila
     */
    public void pop(){
        // implementar

    }
}
