package dci.ed;

public class Cola {
    
    // agregar los elementos que permiten implementar una Cola
    /*
     *  Método que permite agregar al final de la rear
     */
    public void agregarEnCola(int valor){
        // implementar
    }

    /*
     *  Método que permite remover desde el frente de la rear
     */
    public void removerDesdeFrente(){
        // implementar
    }

}
