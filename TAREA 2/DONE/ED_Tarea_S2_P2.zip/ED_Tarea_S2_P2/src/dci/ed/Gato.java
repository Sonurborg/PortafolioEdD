package dci.ed;

public class Gato extends Mascota {
    
    public Gato(){
        sonido=("MIAAAU");
    }
}
