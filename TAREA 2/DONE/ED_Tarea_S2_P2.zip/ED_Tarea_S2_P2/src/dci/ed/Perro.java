package dci.ed;

public class Perro extends Mascota {
    
    public Perro(){
        sonido=("GUAU GUAU");
    }
}
