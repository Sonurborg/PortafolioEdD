package person;

public class PeopleManagr {
    
}
